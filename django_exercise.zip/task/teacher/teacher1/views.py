from django.shortcuts import render,redirect
from rest_framework import viewsets
from .serializer import EmployeeSerializer,TestuserSerializer
from.models import employee,testuser
from rest_framework.authentication import BasicAuthentication,SessionAuthentication,TokenAuthentication
from rest_framework.permissions import AllowAny,IsAuthenticated,IsAdminUser,IsAuthenticatedOrReadOnly,DjangoModelPermissions
#from rest_framework_simplejwt.authentication import JWTAuthentication

class EmployeeViewset(viewsets.ModelViewSet):
    queryset = employee.objects.all()
    serializer_class = EmployeeSerializer

class TestuserViewset(viewsets.ModelViewSet):
    queryset = testuser.objects.all()
    serializer_class = TestuserSerializer

    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

