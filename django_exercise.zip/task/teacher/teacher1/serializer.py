from rest_framework import serializers
from.models import employee,testuser



class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model=employee
        fields='__all__'

class TestuserSerializer(serializers.ModelSerializer):
    class Meta:
        model=testuser
        fields='__all__'